# desktop-manager
### 感谢您下载desktop manager!
##### thanks for your downloader desktop-manager!
____
### 部分代码展示
##### some code
<br>

```python
def github():
    os.system("start https://github.com/isnbmy")


def cmd():
    os.system("start cmd")


def blog():
    os.system("start https://isnbmy.github.io")


def colortype():
    color = colorchooser.askcolor()
    if color is None:
        return 0
    else:
        msg.showinfo(title="desktop manager", message=f"此颜色色号为：{color}")
        return 1


def task():
    os.system("taskmgr")


def gen():
    window = tk.Tk()
    a = window.winfo_screenwidth()
    b = window.winfo_screenheight()
    window.destroy()
    del window
    if str(b) == "2048":
        msg.showinfo(title="desktop manager", message=f"分辨率：2K\n像素:{a}X{b}")
    elif str(b) == "4096":
        msg.showinfo(title="desktop manager", message=f"分辨率：4K\n像素:{a}X{b}")
    elif str(b) == "8192":
        msg.showinfo(title="desktop manager", message=f"分辨率：8K\n像素:{a}X{b}")
    elif str(b) == "16384":
        msg.showinfo(title="desktop manager", message=f"分辨率：16K\n像素:{a}X{b}")
    else:
        msg.showinfo(title="desktop manager", message=f"分辨率：{b}\n像素:{a}X{b}")
```
