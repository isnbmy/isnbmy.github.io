from tkinter import messagebox as msg
import tkinter as tk
from getpass import getuser
import socket
import psutil
from platform import *
import os
from tkinter import colorchooser


def cpu():
    msg.showinfo(title="desktop manager",
                 message=f"cpu逻辑数:{psutil.cpu_count()}\ncpu类型:{machine()}\ncpu核心数:{psutil.cpu_count(logical=False)}")


def user():
    hostName = socket.gethostname()
    ip = socket.gethostbyname(hostName)
    msg.showinfo(title="desktop manager",
                 message=f"主机名：{hostName}\nip地址：{ip}\n此用户名：{getuser()}\n网络名称：{node()}\n系统名称：{f'{system()}{version()}'}")


def about1():
    msg.showinfo(title="desktop manager",
                 message=f"desktop manager\ngithub项目：{'https://github.com/isnbmy/desktop-manager'}")


def startclear():
    if msg.askquestion(title="desktop manager", message="可能会误清理,确定吗？") == "yes":
        os.system("start other/clear.exe")


def csdn():
    os.system("start https://blog.csdn.net/b1145141919")


def github():
    os.system("start https://github.com/isnbmy")


def cmd():
    os.system("start cmd")


def blog():
    os.system("start https://isnbmy.github.io")


def colortype():
    color = colorchooser.askcolor()
    if color is None:
        return 0
    else:
        msg.showinfo(title="desktop manager", message=f"此颜色色号为：{color}")
        return 1


def task():
    os.system("taskmgr")


def gen():
    window = tk.Tk()
    a = window.winfo_screenwidth()
    b = window.winfo_screenheight()
    window.destroy()
    del window
    if str(b) == "2048":
        msg.showinfo(title="desktop manager", message=f"分辨率：2K\n像素:{a}X{b}")
    elif str(b) == "4096":
        msg.showinfo(title="desktop manager", message=f"分辨率：4K\n像素:{a}X{b}")
    elif str(b) == "8192":
        msg.showinfo(title="desktop manager", message=f"分辨率：8K\n像素:{a}X{b}")
    elif str(b) == "16384":
        msg.showinfo(title="desktop manager", message=f"分辨率：16K\n像素:{a}X{b}")
    else:
        msg.showinfo(title="desktop manager", message=f"分辨率：{b}\n像素:{a}X{b}")
