import tkinter as tk
from tkinter import TkVersion
from tkinter import ttk
from function import *


root = tk.Tk()
menu = tk.Menu(root)
about = tk.Menu(menu, tearoff=0)
about.add_command(label="关于desktop manager", command=about1)
about2 = tk.Menu(about)
about2.add_command(label="csdn", command=csdn)
about2.add_command(label="github", command=github)
about2.add_separator()
about2.add_command(label="作者博客", command=blog)
about.add_separator()
about.add_cascade(menu=about2, label="关于作者")
about.add_separator()
about.add_command(label=f"version{0.2}")
about.add_command(label=f"Tk version{TkVersion}")

menu.add_cascade(menu=about, label="关于")
root.geometry(f"{500}x{300}")
ttk.Button(root, text="主机信息", command=user).grid(row=0, column=0)
ttk.Button(root, text="清理垃圾", command=startclear).grid(row=1, column=1)
ttk.Button(root, text="cpu信息", command=cpu).grid(row=1, column=0)
ttk.Button(root, text="屏幕素质", command=gen).grid(row=0, column=1)
ttk.Button(root, text="命令提示符", command=cmd).grid(row=1, column=2)
ttk.Button(root, text="颜色色号查询", command=colortype).grid(row=0, column=2)
ttk.Button(root, text="任务管理器", command=task).grid(row=2, column=0)
ttk.Button(root, text="关闭", command=root.destroy).place(x=413, y=272.5)
root.title("desktop manager")
root.resizable(False, False)
root.config(menu=menu)
root.attributes('-topmost', True)
root.iconbitmap("icon/icon.ico")
root.mainloop()
