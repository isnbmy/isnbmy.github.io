from tkinter import messagebox as msg
from getpass import getuser
import socket
import psutil
from platform import *
import os
from tkinter import colorchooser
def cpu():
    msg.showinfo(title="desktop manager", message=f"cpu逻辑数:{psutil.cpu_count()}\ncpu类型:{machine()}\ncpu核心数:{psutil.cpu_count(logical=False)}")
def user():
    hostName = socket.gethostname()
    ip = socket.gethostbyname(hostName)
    msg.showinfo(title="desktop manager", message=f"主机名：{hostName}\nip地址：{ip}\n此用户名：{getuser()}\n网络名称：{node()}\n系统名称：{f'{system()}{version()}'}")
def about1():
    msg.showinfo(title="desktop manager", message=f"desktop manager\ngithub项目：{'https://github.com/isnbmy/desktop-manager'}")
def startclear():
    os.system("start other/clear.exe")
    msg.showinfo(title="desktop manager", message="正在开始清理，请稍后")
def csdn():
    os.system("start https://blog.csdn.net/b1145141919")
def github():
    os.system("start https://github.com/isnbmy")
def cmd():
    os.system("start cmd")
def blog():
    os.system("start https://isnbmy.github.io")
def colortype():
    color = colorchooser.askcolor()
    if color is None:
        return 0
    else:
        msg.showinfo(title="desktop manager", message=f"此颜色色号为：{color}")
        return 1